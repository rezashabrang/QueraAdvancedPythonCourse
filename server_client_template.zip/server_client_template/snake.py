import consts


class Snake:

    def __init__(self, keys, game, pos, color, direction):
        pass

    def get_head(self):
        pass

    def next_move(self):
        pass

    def handle(self, keys):
        pass
