import socket, json


class Network:

    def __init__(self, host, port):
        pass

    def start(self):
        pass

    def send_data(self, keys):
        pass

    def get_data(self):
        pass
