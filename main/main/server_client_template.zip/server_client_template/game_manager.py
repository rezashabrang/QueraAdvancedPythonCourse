import consts

from cell import Cell


class GameManager:

    def __init__(self, size, screen, sx, sy, block_cells):
        pass

    def add_snake(self, snake):
        pass

    def get_cell(self, pos):
        pass

    def kill(self, killed_snake):
        pass

    def handle(self, keys):
        pass
