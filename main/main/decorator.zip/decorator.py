def decorator():
    pass
def validator():
    pass
@decorator(validator‍):
def argomans(*args,**kwargs):
    return validator(args,kwargs)
def f(*args,**kwargs):
    if validator‍(args,kwargs):
        return f;
    else:
        return 'error'
    