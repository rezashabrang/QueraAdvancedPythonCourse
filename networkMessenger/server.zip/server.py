import socket, threading


def register(username, password):
    user, addrSocket = s.accept()
    if (user == username):
        user.sendall("this username registered")
    user.sendall("you registered successfully")


port = 1234
host = ''
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((host, port))
s.listen(20)
while True:
    commandString = str(s.recv(2048))
    commandString = commandString.split(' ')
    command = commandString[0]
    if command == "register":
        register(command[1], command[2])
